# 健身房管理后端

## 运行前准备

1. **MySQL 8** 已安装并启动，默认端口 3306。
2. 创建数据库：
   ```sql
   CREATE DATABASE IF NOT EXISTS gym_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   ```
3. 修改 `src/main/resources/application.yml` 中的数据库账号密码（默认 root/123456），与本地 MySQL 一致。

## 启动

```bash
mvn spring-boot:run
```

默认端口：**18091**。前端开发服务器需配置代理将 `/api` 转发到 `http://localhost:18091`。

## 本次修复说明（会员列表 500 问题）

- 已开启 **Spring 事务管理**（`@EnableTransactionManagement`），MyBatis 的 SqlSession/JDBC 由 Spring 统一管理，避免 “synchronization is not active” 导致的异常。
- **会员分页** `/api/members/page`：Service 与 Controller 双层 try-catch，任何异常均返回 200 + 空列表，不再返回 500。
- **会员列表** `/api/members`：同样在 Controller 做了异常保护。
- 数据库初始化失败时应用仍可启动（`spring.sql.init.continue-on-error: true`），会员接口在 DB 不可用时返回空数据而非 500。

若仍出现 500，请查看控制台完整异常栈，并确认 MySQL 已启动、`gym_db` 已创建、账号密码正确。

---

## 插入测试数据（具体步骤）

测试数据由启动时的 `DevDataInitializer` 自动插入，**仅当库里还没有 admin 用户时**才会执行。

### 情况一：第一次跑、或想要「完整一套」测试数据

1. **打开 MySQL**（命令行或 Navicat 等），执行：
   ```sql
   DROP DATABASE IF EXISTS gym_db;
   CREATE DATABASE gym_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   ```
2. **确认** `application.yml` 里数据库账号密码正确（默认 root / 123456）。
3. 在项目目录下**启动后端**：
   ```bash
   cd backend
   mvn spring-boot:run
   ```
4. 看到日志里 Tomcat 在 18091 端口启动成功即可。此时会先执行 `db/schema.sql` 建表，再执行 `DevDataInitializer`，插入管理员、教练、会员、课程、排期、器材、预约与评价等全部测试数据。

**登录账号**（密码均为 `123456`）：

| 用户名       | 说明   |
|-------------|--------|
| admin       | 管理员 |
| coach_lee   | 教练   |
| coach_chen  | 教练   |
| member_li   | 会员   |
| member_zhang| 会员   |
| …           | 其他见 DevDataInitializer 中的用户列表 |

### 情况二：库里已经有 admin，只想追加更多测试数据

当前逻辑是：**只要存在 admin 用户，就不会再执行任何初始化插入**。  
若不想清库，可以二选一：

- **做法 A（推荐）**：按「情况一」操作，先 `DROP DATABASE gym_db` 再建库并启动一次，得到全新完整数据。
- **做法 B**：自己用 SQL 或脚本往 `sys_user`、`gym_member`、`gym_coach` 等表里插数据（需保证外键、唯一约束正确），不依赖 `DevDataInitializer`。

### 前端如何配合

1. 前端开发环境需把 `/api` 代理到后端，例如在 `vite.config` 中：
   - `target: 'http://localhost:18091'`
2. 启动前端：
   ```bash
   cd frontend
   npm run dev
   ```
3. 浏览器打开前端地址，用上面表格中的账号登录即可使用完整测试数据。
