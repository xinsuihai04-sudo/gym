@echo off
REM 清理占用端口的Java进程
REM 注意: 需要管理员权限才能终止某些进程

echo 正在清理占用端口的Java进程...
echo.

setlocal enabledelayedexpansion

REM 要检查的端口范围
set START_PORT=18080
set END_PORT=18095

echo 检查端口 %START_PORT% 到 %END_PORT%...

for /l %%p in (%START_PORT%,1,%END_PORT%) do (
    echo 检查端口 %%p...
    netstat -ano | findstr ":%%p " > nul
    if not errorlevel 1 (
        REM 找到占用端口，获取PID
        for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":%%p "') do (
            set PID=%%a
            echo 端口 %%p 被进程 !PID! 占用

            REM 尝试获取进程名
            tasklist /FI "PID eq !PID!" 2>nul | findstr /i "java" > nul
            if not errorlevel 1 (
                echo 正在终止Java进程 !PID!...
                taskkill /PID !PID! /F >nul 2>&1
                if errorlevel 1 (
                    echo 警告: 无法终止进程 !PID! (可能需要管理员权限)
                ) else (
                    echo 成功终止进程 !PID!
                )
            ) else (
                echo 进程 !PID! 不是Java进程，跳过...
            )
        )
    )
)

echo.
echo 清理完成。
echo 注意: 某些进程可能需要管理员权限才能终止。
echo 如果仍有端口占用问题，请尝试:
echo 1. 以管理员身份运行此脚本
echo 2. 修改后端启动端口
echo 3. 手动终止相关进程
pause