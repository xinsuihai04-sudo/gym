-- 修复健身房数据库所有外键约束问题

-- 1. 删除所有错误的外键约束
ALTER TABLE gym_course DROP FOREIGN KEY IF EXISTS fk_course_coach;
ALTER TABLE gym_coach DROP FOREIGN KEY IF EXISTS fk_coach_user;

-- 2. 为 gym_coach 表添加正确的外键约束，引用 gym_user 表
ALTER TABLE gym_coach 
ADD CONSTRAINT fk_coach_gym_user 
FOREIGN KEY (user_id) REFERENCES gym_user(id);

-- 3. 插入教练数据（对应 gym_user 表中的 coach1, coach2）
INSERT INTO gym_coach (user_id, title, intro, years_exp, specialty, rating) VALUES
(2, '高级私人教练', '国家一级健身教练，擅长增肌减脂训练', 8, '力量训练、体能训练', 4.8),
(3, '瑜伽导师', '国际瑜伽协会认证导师，拥有10年教学经验', 10, '瑜伽、普拉提、拉伸', 4.9);

-- 4. 为 gym_course 表重新添加外键约束，引用 gym_coach 表
ALTER TABLE gym_course 
ADD CONSTRAINT fk_course_coach 
FOREIGN KEY (coach_id) REFERENCES gym_coach(id);

-- 5. 插入课程数据（如果表为空）
INSERT INTO gym_course (name, cover_url, description, max_participants, duration_min, difficulty, coach_id) VALUES
('力量训练入门', 'https://example.com/course1.jpg', '适合初学者的力量训练课程，学习基本动作技巧', 15, 60, 1, 1),
('高温瑜伽', 'https://example.com/course2.jpg', '在高温环境下进行的瑜伽练习，增强柔韧性和排毒', 12, 90, 2, 2),
('动感单车', 'https://example.com/course3.jpg', '高强度的有氧运动，配合音乐节奏燃烧脂肪', 20, 45, 3, 1),
('核心训练', 'https://example.com/course4.jpg', '专注于腹部和背部核心肌群的训练', 18, 60, 2, 2);

-- 6. 检查结果
SELECT '教练数据:' AS '';
SELECT * FROM gym_coach;

SELECT '课程数据:' AS '';
SELECT id, name, coach_id FROM gym_course;

SELECT '外键约束汇总:' AS '';
SELECT 
    TABLE_NAME,
    CONSTRAINT_NAME,
    COLUMN_NAME,
    REFERENCED_TABLE_NAME,
    REFERENCED_COLUMN_NAME
FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE TABLE_NAME IN ('gym_member', 'gym_coach', 'gym_course') 
  AND CONSTRAINT_NAME LIKE 'fk_%'
ORDER BY TABLE_NAME;
