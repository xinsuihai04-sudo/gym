-- 修复健身房数据库所有外键约束问题
SET FOREIGN_KEY_CHECKS = 0;

-- 1. 删除所有错误的外键约束
ALTER TABLE gym_course DROP FOREIGN KEY fk_course_coach;
ALTER TABLE gym_coach DROP FOREIGN KEY fk_coach_user;

-- 2. 为 gym_coach 表添加正确的外键约束，引用 gym_user 表
ALTER TABLE gym_coach 
ADD CONSTRAINT fk_coach_gym_user 
FOREIGN KEY (user_id) REFERENCES gym_user(id);

-- 3. 清空并重置 gym_coach 表（确保自增ID从1开始）
TRUNCATE TABLE gym_coach;

-- 4. 插入教练数据（使用简单英文描述避免编码问题）
INSERT INTO gym_coach (user_id, title, intro, years_exp, specialty, rating) VALUES
(2, 'Senior Personal Trainer', 'National level 1 fitness coach', 8, 'Strength training, fitness training', 4.8),
(3, 'Yoga Instructor', 'International Yoga Association certified instructor', 10, 'Yoga, Pilates, Stretching', 4.9);

-- 5. 为 gym_course 表重新添加外键约束，引用 gym_coach 表
ALTER TABLE gym_course 
ADD CONSTRAINT fk_course_coach 
FOREIGN KEY (coach_id) REFERENCES gym_coach(id);

-- 6. 清空并插入课程数据（使用简单英文）
TRUNCATE TABLE gym_course;
INSERT INTO gym_course (name, cover_url, description, max_participants, duration_min, difficulty, coach_id) VALUES
('Strength Training Basics', 'https://example.com/course1.jpg', 'Basic strength training for beginners', 15, 60, 1, 1),
('Hot Yoga', 'https://example.com/course2.jpg', 'Yoga practice in high temperature environment', 12, 90, 2, 2),
('Spinning', 'https://example.com/course3.jpg', 'High-intensity cardio exercise', 20, 45, 3, 1),
('Core Training', 'https://example.com/course4.jpg', 'Focus on abdominal and back core muscles', 18, 60, 2, 2);

SET FOREIGN_KEY_CHECKS = 1;

-- 7. 检查结果
SELECT '教练数据:' AS '';
SELECT id, user_id, title FROM gym_coach;

SELECT '课程数据:' AS '';
SELECT id, name, coach_id FROM gym_course;

SELECT '外键约束汇总:' AS '';
SELECT 
    TABLE_NAME,
    CONSTRAINT_NAME,
    COLUMN_NAME,
    REFERENCED_TABLE_NAME,
    REFERENCED_COLUMN_NAME
FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE TABLE_NAME IN ('gym_member', 'gym_coach', 'gym_course') 
  AND CONSTRAINT_NAME LIKE 'fk_%'
ORDER BY TABLE_NAME;
