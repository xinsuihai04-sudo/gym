-- 修复健身房数据库外键约束问题

-- 1. 删除错误的外键约束（如果存在）
ALTER TABLE gym_member DROP FOREIGN KEY IF EXISTS fk_member_user;

-- 2. 添加正确的外键约束，引用 gym_user 表
ALTER TABLE gym_member 
ADD CONSTRAINT fk_member_gym_user 
FOREIGN KEY (user_id) REFERENCES gym_user(id);

-- 3. 插入测试会员数据（对应 gym_user 表中的 member1, member2, member3）
INSERT INTO gym_member (user_id, gender, birthday, height_cm, weight_kg, join_date, level, remark) VALUES
(4, 1, '1990-05-15', 175, 70.5, '2024-01-10', 2, '活跃会员，喜欢力量训练'),
(5, 2, '1995-08-22', 162, 55.2, '2024-02-15', 1, '新会员，主要参加瑜伽课程'),
(6, 1, '1988-11-30', 180, 80.0, '2023-11-20', 3, '资深会员，每周训练5次');

-- 4. 检查结果
SELECT 'gym_member 表数据:' AS '';
SELECT * FROM gym_member;

SELECT '外键约束信息:' AS '';
SELECT 
    TABLE_NAME,
    CONSTRAINT_NAME,
    COLUMN_NAME,
    REFERENCED_TABLE_NAME,
    REFERENCED_COLUMN_NAME
FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE TABLE_NAME = 'gym_member' 
  AND CONSTRAINT_NAME LIKE 'fk_%';
