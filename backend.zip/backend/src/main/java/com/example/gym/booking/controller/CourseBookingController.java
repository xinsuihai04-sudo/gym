package com.example.gym.booking.controller;

import com.example.gym.booking.dto.CreateBookingRequest;
import com.example.gym.booking.dto.CreateReviewRequest;
import com.example.gym.booking.dto.CreateScheduleRequest;
import com.example.gym.booking.service.CourseBookingService;
import com.example.gym.booking.vo.CourseScheduleVO;
import com.example.gym.booking.vo.MyBookingVO;
import com.example.gym.common.ApiResponse;
import com.example.gym.common.BizException;
import com.example.gym.security.SecurityUtils;
import com.example.gym.system.domain.User;
import jakarta.validation.Valid;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/booking")
public class CourseBookingController {

    private final CourseBookingService bookingService;

    public CourseBookingController(CourseBookingService bookingService) {
        this.bookingService = bookingService;
    }

    @GetMapping("/schedules")
    public ApiResponse<List<CourseScheduleVO>> listSchedules(
            @RequestParam(value = "from", required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime from,
            @RequestParam(value = "to", required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime to
    ) {
        try {
            return ApiResponse.success(bookingService.listSchedules(from, to));
        } catch (Exception e) {
            e.printStackTrace();
            return ApiResponse.success(java.util.Collections.emptyList());
        }
    }

    @PostMapping("/schedules")
    public ApiResponse<Long> createSchedule(@Valid @RequestBody CreateScheduleRequest req) {
        User user = SecurityUtils.getCurrentUser();
        if (user == null || user.getUserType() == null || user.getUserType() != 3) {
            throw new BizException(403, "FORBIDDEN");
        }
        return ApiResponse.success(
                bookingService.createSchedule(req.getCourseId(), req.getCoachId(), req.getRoom(), req.getStartTime(), req.getEndTime(), req.getCapacity())
        );
    }

    @PostMapping("/bookings")
    public ApiResponse<Long> book(@Valid @RequestBody CreateBookingRequest req) {
        User user = SecurityUtils.getCurrentUser();
        if (user == null) {
            throw new BizException(401, "UNAUTHORIZED");
        }
        return ApiResponse.success(bookingService.book(req.getScheduleId(), user.getId()));
    }

    @GetMapping("/bookings/my")
    public ApiResponse<List<MyBookingVO>> myBookings() {
        User user = SecurityUtils.getCurrentUser();
        if (user == null) {
            throw new BizException(401, "UNAUTHORIZED");
        }
        return ApiResponse.success(bookingService.listMyBookings(user.getId()));
    }

    @PostMapping("/bookings/{bookingId}/cancel")
    public ApiResponse<Void> cancel(@PathVariable("bookingId") Long bookingId) {
        User user = SecurityUtils.getCurrentUser();
        if (user == null) {
            throw new BizException(401, "UNAUTHORIZED");
        }
        bookingService.cancel(bookingId, user.getId());
        return ApiResponse.success();
    }

    @PostMapping("/reviews")
    public ApiResponse<Long> review(@Valid @RequestBody CreateReviewRequest req) {
        User user = SecurityUtils.getCurrentUser();
        if (user == null) {
            throw new BizException(401, "UNAUTHORIZED");
        }
        return ApiResponse.success(bookingService.review(req.getScheduleId(), req.getRating(), req.getComment(), user.getId()));
    }
}

