package com.example.gym.booking.domain;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class CourseBooking {

    private Long id;
    private Long scheduleId;
    private Long memberId;
    private LocalDateTime bookingTime;
    private Integer status; // 1已预约 2已取消 3已签到 4缺席
    private LocalDateTime checkinTime;
    private LocalDateTime cancelTime;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private Integer deleted;
}

