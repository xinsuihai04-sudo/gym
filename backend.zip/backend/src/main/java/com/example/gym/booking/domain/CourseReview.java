package com.example.gym.booking.domain;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class CourseReview {

    private Long id;
    private Long scheduleId;
    private Long memberId;
    private Integer rating; // 1-5
    private String comment;
    private LocalDateTime createdAt;
    private Integer deleted;
}

