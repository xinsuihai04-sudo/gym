package com.example.gym.booking.domain;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class CourseSchedule {

    private Long id;
    private Long courseId;
    private Long coachId;
    private String room;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private Integer capacity;
    private Integer bookedCount;
    private Integer status; // 1正常 2取消 3已结束
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private Integer deleted;
}

