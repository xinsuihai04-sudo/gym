package com.example.gym.booking.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class CreateBookingRequest {

    @NotNull
    private Long scheduleId;
}

