package com.example.gym.booking.mapper;

import com.example.gym.booking.domain.CourseBooking;
import com.example.gym.booking.vo.MyBookingVO;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface CourseBookingMapper {

    @Select("""
            SELECT id, schedule_id AS scheduleId, member_id AS memberId,
                   booking_time AS bookingTime, status, checkin_time AS checkinTime,
                   cancel_time AS cancelTime, created_at AS createdAt, updated_at AS updatedAt, deleted
            FROM gym_course_booking
            WHERE id = #{id} AND deleted = 0
            LIMIT 1
            """)
    CourseBooking findById(@Param("id") Long id);

    @Insert("""
            INSERT INTO gym_course_booking (schedule_id, member_id, status, booking_time)
            VALUES (#{scheduleId}, #{memberId}, 1, NOW())
            """)
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(CourseBooking booking);

    @Select("""
            SELECT id, schedule_id AS scheduleId, member_id AS memberId,
                   booking_time AS bookingTime, status, checkin_time AS checkinTime,
                   cancel_time AS cancelTime, created_at AS createdAt, updated_at AS updatedAt, deleted
            FROM gym_course_booking
            WHERE schedule_id = #{scheduleId} AND member_id = #{memberId} AND deleted = 0
            LIMIT 1
            """)
    CourseBooking findByScheduleAndMember(@Param("scheduleId") Long scheduleId, @Param("memberId") Long memberId);

    @Select("""
            SELECT b.id AS bookingId, b.schedule_id AS scheduleId, b.status AS bookingStatus,
                   b.booking_time AS bookingTime, b.cancel_time AS cancelTime,
                   EXISTS(SELECT 1 FROM gym_course_review r WHERE r.schedule_id = b.schedule_id AND r.member_id = b.member_id AND r.deleted = 0) AS reviewed,
                   c.name AS courseName, s.room, s.start_time AS startTime, s.end_time AS endTime
            FROM gym_course_booking b
            JOIN gym_course_schedule s ON s.id = b.schedule_id AND s.deleted = 0
            JOIN gym_course c ON c.id = s.course_id AND c.deleted = 0
            WHERE b.member_id = #{memberId} AND b.deleted = 0
            ORDER BY b.booking_time DESC
            """)
    List<MyBookingVO> listMyBookings(@Param("memberId") Long memberId);

    @Update("""
            UPDATE gym_course_booking
            SET status = 2, cancel_time = NOW()
            WHERE id = #{id} AND member_id = #{memberId} AND deleted = 0 AND status = 1
            """)
    int cancel(@Param("id") Long id, @Param("memberId") Long memberId);
}

