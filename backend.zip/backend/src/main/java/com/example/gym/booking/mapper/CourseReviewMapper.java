package com.example.gym.booking.mapper;

import com.example.gym.booking.domain.CourseReview;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface CourseReviewMapper {

    @Select("""
            SELECT id, schedule_id AS scheduleId, member_id AS memberId, rating, comment,
                   created_at AS createdAt, deleted
            FROM gym_course_review
            WHERE schedule_id = #{scheduleId} AND member_id = #{memberId} AND deleted = 0
            LIMIT 1
            """)
    CourseReview findByScheduleAndMember(@Param("scheduleId") Long scheduleId, @Param("memberId") Long memberId);

    @Insert("""
            INSERT INTO gym_course_review (schedule_id, member_id, rating, comment, created_at, deleted)
            VALUES (#{scheduleId}, #{memberId}, #{rating}, #{comment}, NOW(), 0)
            """)
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(CourseReview review);
}

