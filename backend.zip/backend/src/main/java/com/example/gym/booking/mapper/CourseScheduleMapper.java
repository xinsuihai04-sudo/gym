package com.example.gym.booking.mapper;

import com.example.gym.booking.domain.CourseSchedule;
import com.example.gym.booking.vo.CourseScheduleVO;
import org.apache.ibatis.annotations.*;

import java.time.LocalDateTime;
import java.util.List;

@Mapper
public interface CourseScheduleMapper {

    @Insert("""
            INSERT INTO gym_course_schedule
            (course_id, coach_id, room, start_time, end_time, capacity, booked_count, status)
            VALUES
            (#{courseId}, #{coachId}, #{room}, #{startTime}, #{endTime}, #{capacity}, 0, 1)
            """)
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(CourseSchedule schedule);

    @Select("""
            SELECT cs.id, cs.course_id AS courseId, c.name AS courseName,
                   cs.coach_id AS coachId, gc.title AS coachTitle, su.nickname AS coachNickname,
                   cs.room, cs.start_time AS startTime, cs.end_time AS endTime,
                   cs.capacity, cs.booked_count AS bookedCount, cs.status
            FROM gym_course_schedule cs
            JOIN gym_course c ON c.id = cs.course_id AND c.deleted = 0
            JOIN gym_coach gc ON gc.id = cs.coach_id AND gc.deleted = 0
            JOIN sys_user su ON su.id = gc.user_id AND su.deleted = 0
            WHERE cs.deleted = 0
              AND (#{from} IS NULL OR cs.start_time >= #{from})
              AND (#{to} IS NULL OR cs.start_time <= #{to})
            ORDER BY cs.start_time ASC
            """)
    List<CourseScheduleVO> listSchedules(@Param("from") LocalDateTime from, @Param("to") LocalDateTime to);

    @Select("""
            SELECT id, course_id AS courseId, coach_id AS coachId, room, start_time AS startTime, end_time AS endTime,
                   capacity, booked_count AS bookedCount, status, created_at AS createdAt, updated_at AS updatedAt, deleted
            FROM gym_course_schedule
            WHERE id = #{id} AND deleted = 0
            """)
    CourseSchedule findById(@Param("id") Long id);

    @Update("""
            UPDATE gym_course_schedule
            SET booked_count = booked_count + 1
            WHERE id = #{id} AND deleted = 0 AND status = 1 AND booked_count < capacity
            """)
    int tryIncreaseBooked(@Param("id") Long id);

    @Update("""
            UPDATE gym_course_schedule
            SET booked_count = CASE WHEN booked_count > 0 THEN booked_count - 1 ELSE 0 END
            WHERE id = #{id} AND deleted = 0
            """)
    int decreaseBooked(@Param("id") Long id);
}

