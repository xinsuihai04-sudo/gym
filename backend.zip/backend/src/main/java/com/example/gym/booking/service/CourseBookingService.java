package com.example.gym.booking.service;

import com.example.gym.booking.vo.CourseScheduleVO;
import com.example.gym.booking.vo.MyBookingVO;

import java.time.LocalDateTime;
import java.util.List;

public interface CourseBookingService {

    Long createSchedule(Long courseId, Long coachId, String room, LocalDateTime startTime, LocalDateTime endTime, Integer capacity);

    List<CourseScheduleVO> listSchedules(LocalDateTime from, LocalDateTime to);

    Long book(Long scheduleId, Long userId);

    void cancel(Long bookingId, Long userId);

    List<MyBookingVO> listMyBookings(Long userId);

    Long review(Long scheduleId, Integer rating, String comment, Long userId);
}

