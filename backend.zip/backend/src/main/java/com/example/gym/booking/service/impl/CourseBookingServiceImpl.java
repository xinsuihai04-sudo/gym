package com.example.gym.booking.service.impl;

import com.example.gym.booking.domain.CourseBooking;
import com.example.gym.booking.domain.CourseReview;
import com.example.gym.booking.domain.CourseSchedule;
import com.example.gym.booking.mapper.CourseBookingMapper;
import com.example.gym.booking.mapper.CourseReviewMapper;
import com.example.gym.booking.mapper.CourseScheduleMapper;
import com.example.gym.booking.service.CourseBookingService;
import com.example.gym.booking.vo.CourseScheduleVO;
import com.example.gym.booking.vo.MyBookingVO;
import com.example.gym.common.BizException;
import com.example.gym.member.domain.Member;
import com.example.gym.member.mapper.MemberMapper;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class CourseBookingServiceImpl implements CourseBookingService {

    private final CourseScheduleMapper scheduleMapper;
    private final CourseBookingMapper bookingMapper;
    private final CourseReviewMapper reviewMapper;
    private final MemberMapper memberMapper;

    public CourseBookingServiceImpl(CourseScheduleMapper scheduleMapper,
                                   CourseBookingMapper bookingMapper,
                                   CourseReviewMapper reviewMapper,
                                   MemberMapper memberMapper) {
        this.scheduleMapper = scheduleMapper;
        this.bookingMapper = bookingMapper;
        this.reviewMapper = reviewMapper;
        this.memberMapper = memberMapper;
    }

    @Override
    public Long createSchedule(Long courseId, Long coachId, String room, LocalDateTime startTime, LocalDateTime endTime, Integer capacity) {
        CourseSchedule s = new CourseSchedule();
        s.setCourseId(courseId);
        s.setCoachId(coachId);
        s.setRoom(room);
        s.setStartTime(startTime);
        s.setEndTime(endTime);
        s.setCapacity(capacity);
        scheduleMapper.insert(s);
        return s.getId();
    }

    @Override
    public List<CourseScheduleVO> listSchedules(LocalDateTime from, LocalDateTime to) {
        return scheduleMapper.listSchedules(from, to);
    }

    /**
     * 确保当前用户拥有一条会员资料，如果没有则自动创建一条基础会员记录。
     */
    private Member ensureMember(Long userId) {
        Member member = memberMapper.findByUserId(userId);
        if (member != null) {
            return member;
        }
        Member created = new Member();
        created.setUserId(userId);
        created.setGender(null);
        created.setJoinDate(LocalDate.now());
        created.setLevel(1);
        created.setRemark("系统自动创建会员资料");
        memberMapper.insert(created);
        return created;
    }

    @Override
    @Transactional
    public Long book(Long scheduleId, Long userId) {
        Member member = ensureMember(userId);
        CourseSchedule schedule = scheduleMapper.findById(scheduleId);
        if (schedule == null || schedule.getStatus() == null || schedule.getStatus() != 1) {
            throw new BizException(404, "SCHEDULE_NOT_AVAILABLE");
        }

        CourseBooking existing = bookingMapper.findByScheduleAndMember(scheduleId, member.getId());
        if (existing != null && existing.getStatus() != null && existing.getStatus() == 1) {
            throw new BizException(409, "ALREADY_BOOKED");
        }

        int increased = scheduleMapper.tryIncreaseBooked(scheduleId);
        if (increased == 0) {
            throw new BizException(409, "SCHEDULE_FULL");
        }

        try {
            CourseBooking booking = new CourseBooking();
            booking.setScheduleId(scheduleId);
            booking.setMemberId(member.getId());
            bookingMapper.insert(booking);
            return booking.getId();
        } catch (DuplicateKeyException e) {
            // 唯一键(schedule_id, member_id)冲突：回滚 booked_count
            scheduleMapper.decreaseBooked(scheduleId);
            throw new BizException(409, "ALREADY_BOOKED");
        }
    }

    @Override
    @Transactional
    public void cancel(Long bookingId, Long userId) {
        Member member = ensureMember(userId);
        int updated = bookingMapper.cancel(bookingId, member.getId());
        if (updated == 0) {
            throw new BizException(404, "BOOKING_NOT_FOUND_OR_NOT_CANCELABLE");
        }

        // 找到对应 scheduleId 进行扣减：这里通过查询 myBookings 或补一个 mapper 查询更高效
        // 简化：直接查 booking 记录
        CourseBooking b = bookingMapper.findById(bookingId);
        if (b != null) {
            scheduleMapper.decreaseBooked(b.getScheduleId());
        }
    }

    @Override
    public List<MyBookingVO> listMyBookings(Long userId) {
        Member member = ensureMember(userId);
        return bookingMapper.listMyBookings(member.getId());
    }

    @Override
    @Transactional
    public Long review(Long scheduleId, Integer rating, String comment, Long userId) {
        Member member = ensureMember(userId);
        CourseReview existing = reviewMapper.findByScheduleAndMember(scheduleId, member.getId());
        if (existing != null) {
            throw new BizException(409, "REVIEW_ALREADY_EXISTS");
        }
        CourseBooking booking = bookingMapper.findByScheduleAndMember(scheduleId, member.getId());
        if (booking == null || booking.getStatus() == null || booking.getStatus() == 2) {
            throw new BizException(403, "REVIEW_NOT_ALLOWED");
        }
        CourseReview review = new CourseReview();
        review.setScheduleId(scheduleId);
        review.setMemberId(member.getId());
        review.setRating(rating);
        review.setComment(comment);
        reviewMapper.insert(review);
        return review.getId();
    }
}

