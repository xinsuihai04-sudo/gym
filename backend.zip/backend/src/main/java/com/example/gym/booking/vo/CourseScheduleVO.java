package com.example.gym.booking.vo;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class CourseScheduleVO {

    private Long id;
    private Long courseId;
    private String courseName;
    private Long coachId;
    private String coachTitle;
    private String coachNickname;
    private String room;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private Integer capacity;
    private Integer bookedCount;
    private Integer status;
}

