package com.example.gym.booking.vo;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class MyBookingVO {

    private Long bookingId;
    private Long scheduleId;
    private Integer bookingStatus;
    private LocalDateTime bookingTime;
    private LocalDateTime cancelTime;
    /** 当前用户是否已对该排期评价，1=已评价 0=未评价（与 MySQL EXISTS 返回 0/1 一致） */
    private Integer reviewed;

    private String courseName;
    private String room;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
}

