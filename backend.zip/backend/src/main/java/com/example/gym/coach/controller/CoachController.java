package com.example.gym.coach.controller;

import com.example.gym.coach.domain.Coach;
import com.example.gym.coach.service.CoachService;
import com.example.gym.common.ApiResponse;
import com.example.gym.common.PagedResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/coaches")
public class CoachController {

    private final CoachService coachService;

    public CoachController(CoachService coachService) {
        this.coachService = coachService;
    }

    @GetMapping
    public ApiResponse<List<Coach>> list() {
        try {
            return ApiResponse.success(coachService.listAll());
        } catch (Exception e) {
            e.printStackTrace();
            return ApiResponse.success(java.util.Collections.emptyList());
        }
    }

    /** 分页必须放在 /{id} 之前，否则 GET /api/coaches/page 会匹配成 id=page 导致 500 */
    @GetMapping("/page")
    public ApiResponse<PagedResult<Coach>> listByPage(
            @RequestParam(value = "pageNum", defaultValue = "1") int pageNum,
            @RequestParam(value = "pageSize", defaultValue = "10") int pageSize) {
        try {
            return ApiResponse.success(coachService.listByPage(pageNum, pageSize));
        } catch (Exception e) {
            e.printStackTrace();
            return ApiResponse.success(new PagedResult<>(java.util.Collections.emptyList(), 0L, pageNum, pageSize));
        }
    }

    @GetMapping("/{id}")
    public ApiResponse<Coach> detail(@PathVariable("id") Long id) {
        return ApiResponse.success(coachService.getById(id));
    }

    @PostMapping
    public ApiResponse<Long> create(@RequestBody Coach coach) {
        return ApiResponse.success(coachService.create(coach));
    }

    @PutMapping("/{id}")
    public ApiResponse<Void> update(@PathVariable("id") Long id, @RequestBody Coach coach) {
        coach.setId(id);
        coachService.update(coach);
        return ApiResponse.success();
    }

    @DeleteMapping("/{id}")
    public ApiResponse<Void> delete(@PathVariable("id") Long id) {
        coachService.delete(id);
        return ApiResponse.success();
    }
}

