package com.example.gym.coach.domain;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class Coach {

    private Long id;
    private Long userId;
    private String title;
    private String intro;
    private Integer yearsExp;
    private String specialty;
    private Double rating;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private Integer deleted;
}

