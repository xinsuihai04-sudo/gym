package com.example.gym.coach.mapper;

import com.example.gym.coach.domain.Coach;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface CoachMapper {

    @Select("""
            SELECT id, user_id AS userId, title, intro, years_exp AS yearsExp,
                   specialty, rating, created_at AS createdAt, updated_at AS updatedAt, deleted
            FROM gym_coach
            WHERE deleted = 0
            ORDER BY id DESC
            """)
    List<Coach> findAll();

    @Select("""
            SELECT id, user_id AS userId, title, intro, years_exp AS yearsExp,
                   specialty, rating, created_at AS createdAt, updated_at AS updatedAt, deleted
            FROM gym_coach
            WHERE id = #{id} AND deleted = 0
            """)
    Coach findById(@Param("id") Long id);

    @Insert("""
            INSERT INTO gym_coach (user_id, title, intro, years_exp, specialty, rating)
            VALUES (#{userId}, #{title}, #{intro}, #{yearsExp}, #{specialty}, #{rating})
            """)
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(Coach coach);

    @Update("""
            UPDATE gym_coach
            SET title = #{title},
                intro = #{intro},
                years_exp = #{yearsExp},
                specialty = #{specialty},
                rating = #{rating}
            WHERE id = #{id} AND deleted = 0
            """)
    int update(Coach coach);

    @Select("""
            SELECT COUNT(*) FROM gym_coach WHERE deleted = 0
            """)
    long countAll();

    @Select("""
            SELECT id, user_id AS userId, title, intro, years_exp AS yearsExp,
                   specialty, rating, created_at AS createdAt, updated_at AS updatedAt, deleted
            FROM gym_coach
            WHERE deleted = 0
            ORDER BY id DESC
            LIMIT #{pageSize} OFFSET #{offset}
            """)
    List<Coach> findByPage(@Param("offset") long offset, @Param("pageSize") int pageSize);

    @Update("UPDATE gym_coach SET deleted = 1 WHERE id = #{id} AND deleted = 0")
    int softDelete(@Param("id") Long id);
}

