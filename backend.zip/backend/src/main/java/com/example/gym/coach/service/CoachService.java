package com.example.gym.coach.service;

import com.example.gym.common.PagedResult;
import com.example.gym.coach.domain.Coach;

import java.util.List;

public interface CoachService {

    List<Coach> listAll();

    Coach getById(Long id);

    Long create(Coach coach);

    void update(Coach coach);

    void delete(Long id);

    PagedResult<Coach> listByPage(int pageNum, int pageSize);
}

