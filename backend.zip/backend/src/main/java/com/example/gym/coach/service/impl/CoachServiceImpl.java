package com.example.gym.coach.service.impl;

import com.example.gym.common.PagedResult;
import com.example.gym.common.BizException;
import com.example.gym.coach.domain.Coach;
import com.example.gym.coach.mapper.CoachMapper;
import com.example.gym.coach.service.CoachService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CoachServiceImpl implements CoachService {

    private final CoachMapper coachMapper;

    public CoachServiceImpl(CoachMapper coachMapper) {
        this.coachMapper = coachMapper;
    }

    @Override
    public List<Coach> listAll() {
        return coachMapper.findAll();
    }

    @Override
    public Coach getById(Long id) {
        return coachMapper.findById(id);
    }

    @Override
    public Long create(Coach coach) {
        coachMapper.insert(coach);
        return coach.getId();
    }

    @Override
    public void update(Coach coach) {
        int updated = coachMapper.update(coach);
        if (updated == 0) {
            throw new BizException(404, "COACH_NOT_FOUND");
        }
    }

    @Override
    public void delete(Long id) {
        int updated = coachMapper.softDelete(id);
        if (updated == 0) {
            throw new BizException(404, "COACH_NOT_FOUND");
        }
    }

    @Override
    public PagedResult<Coach> listByPage(int pageNum, int pageSize) {
        long total = coachMapper.countAll();
        long offset = (long) (pageNum - 1) * pageSize;
        List<Coach> list = coachMapper.findByPage(offset, pageSize);
        return new PagedResult<>(list, total, pageNum, pageSize);
    }
}

