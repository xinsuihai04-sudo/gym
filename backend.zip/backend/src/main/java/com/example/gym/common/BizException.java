package com.example.gym.common;

public class BizException extends RuntimeException {

    private final int code;
    private final String messageKey;

    public BizException(int code, String messageKey) {
        super(messageKey);
        this.code = code;
        this.messageKey = messageKey;
    }

    public int getCode() {
        return code;
    }

    public String getMessageKey() {
        return messageKey;
    }
}

