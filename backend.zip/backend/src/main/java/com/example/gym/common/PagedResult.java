package com.example.gym.common;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PagedResult<T> {

    private List<T> list;
    private long total;
    private int pageNum;
    private int pageSize;

    public static <T> PagedResult<T> of(List<T> list, long total, int pageNum, int pageSize) {
        return new PagedResult<>(list, total, pageNum, pageSize);
    }
}