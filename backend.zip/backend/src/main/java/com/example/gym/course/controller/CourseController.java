package com.example.gym.course.controller;

import com.example.gym.common.ApiResponse;
import com.example.gym.course.domain.Course;
import com.example.gym.course.service.CourseService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/courses")
public class CourseController {

    private final CourseService courseService;

    public CourseController(CourseService courseService) {
        this.courseService = courseService;
    }

    @GetMapping
    public ApiResponse<List<Course>> list() {
        try {
            return ApiResponse.success(courseService.listAll());
        } catch (Exception e) {
            e.printStackTrace();
            return ApiResponse.success(java.util.Collections.emptyList());
        }
    }

    @GetMapping("/{id}")
    public ApiResponse<Course> detail(@PathVariable("id") Long id) {
        return ApiResponse.success(courseService.getById(id));
    }

    @PostMapping
    public ApiResponse<Long> create(@RequestBody Course course) {
        return ApiResponse.success(courseService.create(course));
    }

    @PutMapping("/{id}")
    public ApiResponse<Void> update(@PathVariable("id") Long id, @RequestBody Course course) {
        course.setId(id);
        courseService.update(course);
        return ApiResponse.success();
    }

    @DeleteMapping("/{id}")
    public ApiResponse<Void> delete(@PathVariable("id") Long id) {
        courseService.delete(id);
        return ApiResponse.success();
    }
}

