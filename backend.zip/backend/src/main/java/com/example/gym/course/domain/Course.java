package com.example.gym.course.domain;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class Course {

    private Long id;
    private String name;
    private String coverUrl;
    private String description;
    private Integer maxParticipants;
    private Integer durationMin;
    private Integer difficulty;
    private Long coachId;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private Integer deleted;
}

