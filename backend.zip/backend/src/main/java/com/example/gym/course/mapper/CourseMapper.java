package com.example.gym.course.mapper;

import com.example.gym.course.domain.Course;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

@Mapper
public interface CourseMapper {

    @Select("""
            SELECT id, name, cover_url AS coverUrl, description, max_participants AS maxParticipants,
                   duration_min AS durationMin, difficulty, coach_id AS coachId, created_at AS createdAt,
                   updated_at AS updatedAt, deleted
            FROM gym_course
            WHERE deleted = 0
            ORDER BY id DESC
            """)
    List<Course> findAll();

    @Select("""
            SELECT id, name, cover_url AS coverUrl, description, max_participants AS maxParticipants,
                   duration_min AS durationMin, difficulty, coach_id AS coachId, created_at AS createdAt,
                   updated_at AS updatedAt, deleted
            FROM gym_course
            WHERE id = #{id} AND deleted = 0
            """)
    Course findById(@Param("id") Long id);

    @Insert("""
            INSERT INTO gym_course (name, cover_url, description, max_participants, duration_min, difficulty, coach_id)
            VALUES (#{name}, #{coverUrl}, #{description}, #{maxParticipants}, #{durationMin}, #{difficulty}, #{coachId})
            """)
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(Course course);

    @Update("""
            UPDATE gym_course
            SET name = #{name},
                cover_url = #{coverUrl},
                description = #{description},
                max_participants = #{maxParticipants},
                duration_min = #{durationMin},
                difficulty = #{difficulty},
                coach_id = #{coachId}
            WHERE id = #{id} AND deleted = 0
            """)
    int update(Course course);

    @Update("UPDATE gym_course SET deleted = 1 WHERE id = #{id} AND deleted = 0")
    int softDelete(@Param("id") Long id);
}

