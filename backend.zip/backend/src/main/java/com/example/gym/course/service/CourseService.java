package com.example.gym.course.service;

import com.example.gym.course.domain.Course;

import java.util.List;

public interface CourseService {

    List<Course> listAll();

    Course getById(Long id);

    Long create(Course course);

    void update(Course course);

    void delete(Long id);
}

