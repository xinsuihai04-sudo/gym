package com.example.gym.course.service.impl;

import com.example.gym.course.domain.Course;
import com.example.gym.course.mapper.CourseMapper;
import com.example.gym.course.service.CourseService;
import com.example.gym.common.BizException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CourseServiceImpl implements CourseService {

    private final CourseMapper courseMapper;

    public CourseServiceImpl(CourseMapper courseMapper) {
        this.courseMapper = courseMapper;
    }

    @Override
    public List<Course> listAll() {
        return courseMapper.findAll();
    }

    @Override
    public Course getById(Long id) {
        return courseMapper.findById(id);
    }

    @Override
    public Long create(Course course) {
        courseMapper.insert(course);
        return course.getId();
    }

    @Override
    public void update(Course course) {
        if (course == null || course.getId() == null) {
            throw new BizException(400, "BAD_REQUEST_BODY");
        }
        if (!org.springframework.util.StringUtils.hasText(course.getName())) {
            throw new BizException(400, "BAD_REQUEST_BODY");
        }
        if (course.getMaxParticipants() == null || course.getDurationMin() == null) {
            throw new BizException(400, "BAD_REQUEST_BODY");
        }
        int updated = courseMapper.update(course);
        if (updated == 0) {
            throw new BizException(404, "COURSE_NOT_FOUND");
        }
    }

    @Override
    public void delete(Long id) {
        int updated = courseMapper.softDelete(id);
        if (updated == 0) {
            throw new BizException(404, "COURSE_NOT_FOUND");
        }
    }
}

