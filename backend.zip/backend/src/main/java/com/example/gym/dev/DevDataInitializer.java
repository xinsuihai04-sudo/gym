package com.example.gym.dev;

import org.springframework.boot.CommandLineRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * 开发环境初始化数据：
 * - 避免未导入 seed-data.sql 导致无法登录、列表 500
 * - 若已存在 admin 用户则跳过
 */
@Component
public class DevDataInitializer implements CommandLineRunner {

    private static final String DEFAULT_BCRYPT_123456 =
            "$2a$10$QIIzlSSmcS1/6hem/hMMYu7MkiF7B4VbZAgglocxXPGmE59pzrrKO";

    private final JdbcTemplate jdbcTemplate;

    public DevDataInitializer(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public void run(String... args) {
        Integer exists = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM sys_user WHERE username='admin' AND deleted=0",
                Integer.class
        );
        if (exists != null && exists > 0) {
            return;
        }

        // 1) users
        upsertUser("admin", "管理员", "13800000000", 3);
        upsertUser("coach_lee", "李教练", "13800000011", 2);
        upsertUser("coach_chen", "陈教练", "13800000012", 2);
        upsertUser("member_li", "李雷", "13800000021", 1);
        upsertUser("member_zhang", "张三", "13800000022", 1);
        upsertUser("member_wang", "王芳", "13800000023", 1);
        upsertUser("member_zhao", "赵敏", "13800000024", 1);
        upsertUser("coach_wang", "王教练", "13800000013", 2);
        upsertUser("member_zhou", "周杰", "13800000025", 1);
        upsertUser("member_liu", "刘洋", "13800000026", 1);
        upsertUser("member_chen", "陈静", "13800000027", 1);
        upsertUser("member_sun", "孙婷", "13800000028", 1);
        upsertUser("member_huang", "黄明", "13800000029", 1);
        upsertUser("coach_liu", "刘教练", "13800000014", 2);
        upsertUser("coach_zhao", "赵教练", "13800000015", 2);
        upsertUser("member_wu", "吴磊", "13800000030", 1);
        upsertUser("member_zheng", "郑丽", "13800000031", 1);
        upsertUser("member_gao", "高强", "13800000032", 1);
        upsertUser("member_lin", "林娜", "13800000033", 1);
        upsertUser("member_he", "何俊", "13800000034", 1);
        upsertUser("member_xu", "徐薇", "13800000035", 1);
        upsertUser("member_ma", "马超", "13800000036", 1);
        upsertUser("member_jiang", "江涛", "13800000037", 1);

        // 2) coach
        Long coachLeeUserId = getUserId("coach_lee");
        Long coachChenUserId = getUserId("coach_chen");
        jdbcTemplate.update("""
                INSERT INTO gym_coach (user_id, title, intro, years_exp, specialty, rating, deleted)
                VALUES (?, '高级私教', '擅长增肌塑形与力量训练', 6, '增肌/力量/塑形', 4.9, 0)
                ON DUPLICATE KEY UPDATE title=VALUES(title), intro=VALUES(intro), years_exp=VALUES(years_exp),
                                        specialty=VALUES(specialty), rating=VALUES(rating), deleted=0
                """, coachLeeUserId);
        jdbcTemplate.update("""
                INSERT INTO gym_coach (user_id, title, intro, years_exp, specialty, rating, deleted)
                VALUES (?, '团课教练', '擅长燃脂与HIIT团课', 4, '燃脂/HIIT/有氧', 4.8, 0)
                ON DUPLICATE KEY UPDATE title=VALUES(title), intro=VALUES(intro), years_exp=VALUES(years_exp),
                                        specialty=VALUES(specialty), rating=VALUES(rating), deleted=0
                """, coachChenUserId);
        Long coachWangUserId = getUserId("coach_wang");
        jdbcTemplate.update("""
                INSERT INTO gym_coach (user_id, title, intro, years_exp, specialty, rating, deleted)
                VALUES (?, '瑜伽教练', '普拉提与柔韧训练', 5, '瑜伽/普拉提/拉伸', 4.7, 0)
                ON DUPLICATE KEY UPDATE title=VALUES(title), intro=VALUES(intro), years_exp=VALUES(years_exp),
                                        specialty=VALUES(specialty), rating=VALUES(rating), deleted=0
                """, coachWangUserId);
        Long coachLiuUserId = getUserId("coach_liu");
        Long coachZhaoUserId = getUserId("coach_zhao");
        jdbcTemplate.update("""
                INSERT INTO gym_coach (user_id, title, intro, years_exp, specialty, rating, deleted)
                VALUES (?, '拳击教练', '拳击与体能训练', 5, '拳击/体能/核心', 4.85, 0)
                ON DUPLICATE KEY UPDATE title=VALUES(title), intro=VALUES(intro), years_exp=VALUES(years_exp),
                                        specialty=VALUES(specialty), rating=VALUES(rating), deleted=0
                """, coachLiuUserId);
        jdbcTemplate.update("""
                INSERT INTO gym_coach (user_id, title, intro, years_exp, specialty, rating, deleted)
                VALUES (?, '团课主管', '有氧舞蹈与踏板操', 7, '有氧/踏板/舞蹈', 4.9, 0)
                ON DUPLICATE KEY UPDATE title=VALUES(title), intro=VALUES(intro), years_exp=VALUES(years_exp),
                                        specialty=VALUES(specialty), rating=VALUES(rating), deleted=0
                """, coachZhaoUserId);

        Long coachLeeId = jdbcTemplate.queryForObject("SELECT id FROM gym_coach WHERE user_id=? AND deleted=0", Long.class, coachLeeUserId);
        Long coachChenId = jdbcTemplate.queryForObject("SELECT id FROM gym_coach WHERE user_id=? AND deleted=0", Long.class, coachChenUserId);
        Long coachWangId = jdbcTemplate.queryForObject("SELECT id FROM gym_coach WHERE user_id=? AND deleted=0", Long.class, coachWangUserId);
        Long coachLiuId = jdbcTemplate.queryForObject("SELECT id FROM gym_coach WHERE user_id=? AND deleted=0", Long.class, coachLiuUserId);
        Long coachZhaoId = jdbcTemplate.queryForObject("SELECT id FROM gym_coach WHERE user_id=? AND deleted=0", Long.class, coachZhaoUserId);

        // 3) member
        Long memberLiUserId = getUserId("member_li");
        Long memberZhangUserId = getUserId("member_zhang");
        jdbcTemplate.update("""
                INSERT INTO gym_member (user_id, gender, join_date, level, remark, deleted)
                VALUES (?, 1, ?, 2, '测试会员A', 0)
                ON DUPLICATE KEY UPDATE gender=VALUES(gender), join_date=VALUES(join_date), level=VALUES(level),
                                        remark=VALUES(remark), deleted=0
                """, memberLiUserId, Date.valueOf(LocalDate.now()));
        jdbcTemplate.update("""
                INSERT INTO gym_member (user_id, gender, join_date, level, remark, deleted)
                VALUES (?, 2, ?, 1, '测试会员B', 0)
                ON DUPLICATE KEY UPDATE gender=VALUES(gender), join_date=VALUES(join_date), level=VALUES(level),
                                        remark=VALUES(remark), deleted=0
                """, memberZhangUserId, Date.valueOf(LocalDate.now()));
        Long memberWangUserId = getUserId("member_wang");
        Long memberZhaoUserId = getUserId("member_zhao");
        jdbcTemplate.update("""
                INSERT INTO gym_member (user_id, gender, join_date, level, remark, deleted)
                VALUES (?, 2, ?, 2, '测试会员C', 0)
                ON DUPLICATE KEY UPDATE gender=VALUES(gender), join_date=VALUES(join_date), level=VALUES(level),
                                        remark=VALUES(remark), deleted=0
                """, memberWangUserId, Date.valueOf(LocalDate.now()));
        jdbcTemplate.update("""
                INSERT INTO gym_member (user_id, gender, join_date, level, remark, deleted)
                VALUES (?, 1, ?, 1, '测试会员D', 0)
                ON DUPLICATE KEY UPDATE gender=VALUES(gender), join_date=VALUES(join_date), level=VALUES(level),
                                        remark=VALUES(remark), deleted=0
                """, memberZhaoUserId, Date.valueOf(LocalDate.now()));
        for (String[] u : new String[][]{
                {"member_zhou", "1", "2", "测试会员E"},
                {"member_liu", "1", "1", "测试会员F"},
                {"member_chen", "2", "3", "VIP会员"},
                {"member_sun", "2", "2", "测试会员G"},
                {"member_huang", "1", "1", "测试会员H"},
                {"member_wu", "1", "2", "测试会员I"},
                {"member_zheng", "2", "1", "测试会员J"},
                {"member_gao", "1", "3", "长期会员"},
                {"member_lin", "2", "2", "测试会员K"},
                {"member_he", "1", "1", "测试会员L"},
                {"member_xu", "2", "2", "测试会员M"},
                {"member_ma", "1", "1", "新会员"},
                {"member_jiang", "1", "2", "测试会员N"}
        }) {
            Long uid = getUserId(u[0]);
            jdbcTemplate.update("""
                    INSERT INTO gym_member (user_id, gender, join_date, level, remark, deleted)
                    VALUES (?, ?, ?, ?, ?, 0)
                    ON DUPLICATE KEY UPDATE gender=VALUES(gender), join_date=VALUES(join_date), level=VALUES(level),
                                            remark=VALUES(remark), deleted=0
                    """, uid, Integer.parseInt(u[1]), Date.valueOf(LocalDate.now()), Integer.parseInt(u[2]), u[3]);
        }

        // 4) courses (用名称+deleted=0 做幂等，不强行固定 id)
        upsertCourse("力量训练入门", "全身基础力量与动作模式训练", 20, 60, 1, coachLeeId);
        upsertCourse("HIIT燃脂团课", "高强度间歇训练，提升心肺与燃脂效率", 30, 45, 2, coachChenId);
        upsertCourse("核心稳定训练", "核心力量与稳定性提升", 25, 50, 1, coachLeeId);
        upsertCourse("瑜伽入门", "基础体式与呼吸法", 15, 60, 1, coachWangId);
        upsertCourse("动感单车", "有氧骑行与节奏训练", 25, 45, 2, coachChenId);
        upsertCourse("搏击操", "有氧搏击，释放压力", 20, 50, 2, coachChenId);
        upsertCourse("拉伸放松", "运动后拉伸与放松", 18, 45, 1, coachWangId);
        upsertCourse("杠铃操", "全身塑形杠铃课程", 22, 55, 2, coachLeeId);
        upsertCourse("普拉提入门", "核心控制与体态矫正", 12, 60, 1, coachWangId);
        upsertCourse("拳击入门", "基础拳法与步法、体能", 16, 50, 2, coachLiuId);
        upsertCourse("踏板操", "有氧踏板，提升心肺与协调", 20, 45, 2, coachZhaoId);
        upsertCourse("有氧舞蹈", "流行有氧舞蹈，趣味燃脂", 25, 50, 1, coachZhaoId);
        upsertCourse("TRX悬吊训练", "全身抗阻与核心", 12, 45, 2, coachLiuId);
        upsertCourse("战绳训练", "爆发力与心肺", 15, 40, 2, coachChenId);

        Long c1 = getCourseId("力量训练入门");
        Long c2 = getCourseId("HIIT燃脂团课");
        Long c3 = getCourseId("核心稳定训练");
        Long c4 = getCourseId("瑜伽入门");
        Long c5 = getCourseId("动感单车");
        Long c6 = getCourseId("搏击操");
        Long c7 = getCourseId("拉伸放松");
        Long c8 = getCourseId("杠铃操");
        Long c9 = getCourseId("普拉提入门");
        Long c10 = getCourseId("拳击入门");
        Long c11 = getCourseId("踏板操");
        Long c12 = getCourseId("有氧舞蹈");
        Long c13 = getCourseId("TRX悬吊训练");
        Long c14 = getCourseId("战绳训练");

        // 5) schedules: 若同课程同开始时间已存在则不重复插入
        LocalDateTime base = LocalDateTime.now().withHour(0).withMinute(0).withSecond(0).withNano(0);
        insertScheduleIfNotExists(c1, coachLeeId, "A馆-团课室1", base.plusDays(1).withHour(9), 60, 20);
        insertScheduleIfNotExists(c2, coachChenId, "A馆-团课室2", base.plusDays(1).withHour(14), 45, 30);
        insertScheduleIfNotExists(c3, coachLeeId, "A馆-团课室1", base.plusDays(2).withHour(10), 50, 25);
        insertScheduleIfNotExists(c4, coachWangId, "B馆-瑜伽室", base.plusDays(1).withHour(10), 60, 15);
        insertScheduleIfNotExists(c5, coachChenId, "A馆-单车房", base.plusDays(2).withHour(19), 45, 25);
        insertScheduleIfNotExists(c1, coachLeeId, "A馆-团课室1", base.plusDays(4).withHour(9), 60, 20);
        insertScheduleIfNotExists(c2, coachChenId, "A馆-团课室2", base.plusDays(5).withHour(14), 45, 30);
        insertScheduleIfNotExists(c6, coachChenId, "A馆-团课室2", base.plusDays(3).withHour(18), 50, 20);
        insertScheduleIfNotExists(c7, coachWangId, "B馆-瑜伽室", base.plusDays(2).withHour(11), 45, 18);
        insertScheduleIfNotExists(c8, coachLeeId, "A馆-团课室1", base.plusDays(6).withHour(10), 55, 22);
        insertScheduleIfNotExists(c9, coachWangId, "B馆-瑜伽室", base.plusDays(3).withHour(9), 60, 12);
        insertScheduleIfNotExists(c4, coachWangId, "B馆-瑜伽室", base.plusDays(7).withHour(10), 60, 15);
        insertScheduleIfNotExists(c5, coachChenId, "A馆-单车房", base.plusDays(4).withHour(19), 45, 25);
        insertScheduleIfNotExists(c6, coachChenId, "A馆-团课室2", base.plusDays(8).withHour(18), 50, 20);
        insertScheduleIfNotExists(c1, coachLeeId, "A馆-团课室1", base.plusDays(10).withHour(9), 60, 20);
        insertScheduleIfNotExists(c2, coachChenId, "A馆-团课室2", base.plusDays(11).withHour(14), 45, 30);
        insertScheduleIfNotExists(c10, coachLiuId, "A馆-团课室2", base.plusDays(1).withHour(18), 50, 16);
        insertScheduleIfNotExists(c11, coachZhaoId, "A馆-团课室1", base.plusDays(2).withHour(15), 45, 20);
        insertScheduleIfNotExists(c12, coachZhaoId, "A馆-团课室2", base.plusDays(3).withHour(10), 50, 25);
        insertScheduleIfNotExists(c13, coachLiuId, "B馆-功能训练区", base.plusDays(4).withHour(11), 45, 12);
        insertScheduleIfNotExists(c14, coachChenId, "A馆-团课室2", base.plusDays(5).withHour(17), 40, 15);
        insertScheduleIfNotExists(c10, coachLiuId, "A馆-团课室2", base.plusDays(7).withHour(18), 50, 16);
        insertScheduleIfNotExists(c11, coachZhaoId, "A馆-团课室1", base.plusDays(9).withHour(15), 45, 20);
        insertScheduleIfNotExists(c12, coachZhaoId, "A馆-团课室2", base.plusDays(12).withHour(10), 50, 25);

        // 5.1) 部分预约与评价测试数据（需在 schedule 插入后执行，且依赖 member_id）
        insertBookingAndReviewIfNotExists();

        // 6) equipment（更多器材覆盖有氧、力量、功能区）
        upsertEquipment("EQ-TM-001", "跑步机-01", "跑步机", "A馆-有氧区", 1, LocalDate.of(2025, 1, 10));
        upsertEquipment("EQ-EL-001", "椭圆机-01", "椭圆机", "A馆-有氧区", 1, LocalDate.of(2025, 2, 15));
        upsertEquipment("EQ-BK-001", "动感单车-01", "动感单车", "A馆-单车区", 3, LocalDate.of(2024, 12, 1));
        upsertEquipment("EQ-TM-002", "跑步机-02", "跑步机", "A馆-有氧区", 1, LocalDate.of(2025, 1, 15));
        upsertEquipment("EQ-DB-001", "哑铃组-01", "自由力量", "B馆-力量区", 1, LocalDate.of(2024, 11, 1));
        upsertEquipment("EQ-EL-002", "椭圆机-02", "椭圆机", "A馆-有氧区", 1, LocalDate.of(2025, 2, 20));
        upsertEquipment("EQ-BK-002", "动感单车-02", "动感单车", "A馆-单车区", 1, LocalDate.of(2024, 12, 10));
        upsertEquipment("EQ-SM-001", "史密斯机-01", "固定器械", "B馆-力量区", 1, LocalDate.of(2024, 10, 1));
        upsertEquipment("EQ-BP-001", "卧推架-01", "自由力量", "B馆-力量区", 1, LocalDate.of(2024, 9, 15));
        upsertEquipment("EQ-RW-001", "划船机-01", "有氧器材", "A馆-有氧区", 2, LocalDate.of(2024, 8, 1));
        upsertEquipment("EQ-TM-003", "跑步机-03", "跑步机", "A馆-有氧区", 1, LocalDate.of(2025, 3, 1));
        upsertEquipment("EQ-KB-001", "壶铃组", "自由力量", "B馆-功能训练区", 1, LocalDate.of(2024, 11, 20));
        upsertEquipment("EQ-TM-004", "跑步机-04", "跑步机", "A馆-有氧区", 1, LocalDate.of(2025, 2, 1));
        upsertEquipment("EQ-EL-003", "椭圆机-03", "椭圆机", "A馆-有氧区", 1, LocalDate.of(2025, 1, 20));
        upsertEquipment("EQ-LP-001", "腿举机-01", "固定器械", "B馆-力量区", 1, LocalDate.of(2024, 10, 15));
        upsertEquipment("EQ-LAT-001", "高位下拉-01", "固定器械", "B馆-力量区", 1, LocalDate.of(2024, 9, 20));
        upsertEquipment("EQ-TRX-001", "TRX悬吊带", "功能训练", "B馆-功能训练区", 1, LocalDate.of(2024, 12, 15));
        upsertEquipment("EQ-Rope-001", "战绳", "功能训练", "B馆-功能训练区", 1, LocalDate.of(2024, 11, 10));
        upsertEquipment("EQ-PT-001", "踏板-01", "团课器材", "A馆-团课室1", 1, LocalDate.of(2024, 8, 20));
        upsertEquipment("EQ-PT-002", "踏板-02", "团课器材", "A馆-团课室2", 1, LocalDate.of(2024, 8, 25));
        upsertEquipment("EQ-Cable-001", "龙门架-01", "固定器械", "B馆-力量区", 1, LocalDate.of(2024, 7, 1));
        upsertEquipment("EQ-TM-005", "跑步机-05", "跑步机", "A馆-有氧区", 2, LocalDate.of(2024, 6, 1));
    }

    /** 插入预约与评价测试数据，便于测试预约/取消/评价流程；已存在则跳过。 */
    private void insertBookingAndReviewIfNotExists() {
        List<Long> memberIds = jdbcTemplate.queryForList(
                "SELECT id FROM gym_member WHERE user_id IN (SELECT id FROM sys_user WHERE username IN (" +
                "'member_li','member_zhang','member_wang','member_zhao','member_zhou','member_liu','member_chen'," +
                "'member_sun','member_huang','member_wu','member_zheng','member_gao','member_lin','member_he','member_xu','member_ma','member_jiang')) AND deleted=0 ORDER BY id",
                Long.class
        );
        List<Long> scheduleIds = jdbcTemplate.queryForList(
                "SELECT id FROM gym_course_schedule WHERE deleted=0 ORDER BY start_time ASC LIMIT 25",
                Long.class
        );
        if (memberIds.isEmpty() || scheduleIds.size() < 5) return;
        // 为不同会员预约不同排期，并补充部分评价
        int mi = 0;
        for (int i = 0; i < Math.min(18, scheduleIds.size()); i++) {
            Long sid = scheduleIds.get(i);
            Long mid = memberIds.get(mi % memberIds.size());
            mi++;
            try {
                jdbcTemplate.update("""
                        INSERT INTO gym_course_booking (schedule_id, member_id, status, booking_time)
                        VALUES (?, ?, 1, NOW())
                        """, sid, mid);
                jdbcTemplate.update("UPDATE gym_course_schedule SET booked_count = booked_count + 1 WHERE id = ? AND deleted = 0", sid);
            } catch (Exception ignored) { /* 已预约则忽略 */ }
        }
        // 为前几条预约添加评价
        for (int i = 0; i < Math.min(8, scheduleIds.size()); i++) {
            Long sid = scheduleIds.get(i);
            Long mid = memberIds.get(i % memberIds.size());
            String[] comments = {"课程节奏很好，教练很专业", "强度适中，下次还来", "环境不错，推荐", "教练讲解清晰", "很累但很爽", "适合新手", "教练很耐心", "会再预约"};
            try {
                jdbcTemplate.update("""
                        INSERT INTO gym_course_review (schedule_id, member_id, rating, comment, deleted)
                        VALUES (?, ?, ?, ?, 0)
                        """, sid, mid, 4 + (i % 2), comments[i % comments.length]);
            } catch (Exception ignored) { /* 已评价则忽略 */ }
        }
    }

    private void upsertUser(String username, String nickname, String phone, int userType) {
        jdbcTemplate.update("""
                INSERT INTO sys_user (username, password, nickname, phone, status, user_type, deleted)
                VALUES (?, ?, ?, ?, 1, ?, 0)
                ON DUPLICATE KEY UPDATE password=VALUES(password), nickname=VALUES(nickname), phone=VALUES(phone),
                                        status=1, user_type=VALUES(user_type), deleted=0
                """, username, DEFAULT_BCRYPT_123456, nickname, phone, userType);
    }

    private Long getUserId(String username) {
        return jdbcTemplate.queryForObject("SELECT id FROM sys_user WHERE username=? AND deleted=0", Long.class, username);
    }

    private void upsertCourse(String name, String desc, int max, int duration, int difficulty, Long coachId) {
        Integer exists = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gym_course WHERE name=? AND deleted=0",
                Integer.class,
                name
        );
        if (exists != null && exists > 0) {
            jdbcTemplate.update("""
                    UPDATE gym_course
                    SET description=?, max_participants=?, duration_min=?, difficulty=?, coach_id=?
                    WHERE name=? AND deleted=0
                    """, desc, max, duration, difficulty, coachId, name);
            return;
        }
        jdbcTemplate.update("""
                INSERT INTO gym_course (name, description, max_participants, duration_min, difficulty, coach_id, deleted)
                VALUES (?, ?, ?, ?, ?, ?, 0)
                """, name, desc, max, duration, difficulty, coachId);
    }

    private Long getCourseId(String name) {
        return jdbcTemplate.queryForObject("SELECT id FROM gym_course WHERE name=? AND deleted=0 ORDER BY id DESC LIMIT 1", Long.class, name);
    }

    private void insertScheduleIfNotExists(Long courseId, Long coachId, String room, LocalDateTime start, int durationMin, int capacity) {
        Integer cnt = jdbcTemplate.queryForObject("""
                SELECT COUNT(*) FROM gym_course_schedule
                WHERE course_id=? AND start_time=? AND deleted=0
                """, Integer.class, courseId, java.sql.Timestamp.valueOf(start));
        if (cnt != null && cnt > 0) return;
        jdbcTemplate.update("""
                INSERT INTO gym_course_schedule
                (course_id, coach_id, room, start_time, end_time, capacity, booked_count, status, deleted)
                VALUES (?, ?, ?, ?, DATE_ADD(?, INTERVAL ? MINUTE), ?, 0, 1, 0)
                """,
                courseId, coachId, room,
                java.sql.Timestamp.valueOf(start),
                java.sql.Timestamp.valueOf(start),
                durationMin,
                capacity
        );
    }

    private void upsertEquipment(String code, String name, String type, String location, int status, LocalDate installDate) {
        jdbcTemplate.update("""
                INSERT INTO gym_equipment (equipment_code, name, type, location, status, install_date, deleted)
                VALUES (?, ?, ?, ?, ?, ?, 0)
                ON DUPLICATE KEY UPDATE name=VALUES(name), type=VALUES(type), location=VALUES(location),
                                        status=VALUES(status), install_date=VALUES(install_date), deleted=0
                """, code, name, type, location, status, Date.valueOf(installDate));
    }
}

