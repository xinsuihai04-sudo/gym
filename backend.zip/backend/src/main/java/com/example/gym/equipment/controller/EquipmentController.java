package com.example.gym.equipment.controller;

import com.example.gym.common.ApiResponse;
import com.example.gym.equipment.domain.Equipment;
import com.example.gym.equipment.service.EquipmentService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/equipments")
public class EquipmentController {

    private final EquipmentService equipmentService;

    public EquipmentController(EquipmentService equipmentService) {
        this.equipmentService = equipmentService;
    }

    @GetMapping
    public ApiResponse<List<Equipment>> list() {
        try {
            return ApiResponse.success(equipmentService.listAll());
        } catch (Exception e) {
            e.printStackTrace();
            return ApiResponse.success(java.util.Collections.emptyList());
        }
    }

    @GetMapping("/{id}")
    public ApiResponse<Equipment> detail(@PathVariable("id") Long id) {
        return ApiResponse.success(equipmentService.getById(id));
    }

    @PostMapping
    public ApiResponse<Long> create(@RequestBody Equipment equipment) {
        return ApiResponse.success(equipmentService.create(equipment));
    }

    @PutMapping("/{id}")
    public ApiResponse<Void> update(@PathVariable("id") Long id, @RequestBody Equipment equipment) {
        equipment.setId(id);
        equipmentService.update(equipment);
        return ApiResponse.success();
    }

    @DeleteMapping("/{id}")
    public ApiResponse<Void> delete(@PathVariable("id") Long id) {
        equipmentService.delete(id);
        return ApiResponse.success();
    }
}

