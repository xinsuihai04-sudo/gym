package com.example.gym.equipment.domain;

import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class Equipment {

    private Long id;
    private String equipmentCode;
    private String name;
    private String type;
    private String location;
    private Integer status;
    private LocalDate installDate;
    private LocalDateTime lastOnlineAt;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private Integer deleted;
}

