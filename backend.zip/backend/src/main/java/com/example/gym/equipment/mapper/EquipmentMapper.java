package com.example.gym.equipment.mapper;

import com.example.gym.equipment.domain.Equipment;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface EquipmentMapper {

    @Select("""
            SELECT id, equipment_code AS equipmentCode, name, type, location, status,
                   install_date AS installDate, last_online_at AS lastOnlineAt,
                   created_at AS createdAt, updated_at AS updatedAt, deleted
            FROM gym_equipment
            WHERE deleted = 0
            ORDER BY id DESC
            """)
    List<Equipment> findAll();

    @Select("""
            SELECT id, equipment_code AS equipmentCode, name, type, location, status,
                   install_date AS installDate, last_online_at AS lastOnlineAt,
                   created_at AS createdAt, updated_at AS updatedAt, deleted
            FROM gym_equipment
            WHERE id = #{id} AND deleted = 0
            """)
    Equipment findById(@Param("id") Long id);

    @Insert("""
            INSERT INTO gym_equipment (equipment_code, name, type, location, status, install_date)
            VALUES (#{equipmentCode}, #{name}, #{type}, #{location}, #{status}, #{installDate})
            """)
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(Equipment equipment);

    @Update("""
            UPDATE gym_equipment
            SET name = #{name},
                type = #{type},
                location = #{location},
                status = #{status},
                install_date = #{installDate}
            WHERE id = #{id} AND deleted = 0
            """)
    int update(Equipment equipment);

    @Update("UPDATE gym_equipment SET deleted = 1 WHERE id = #{id} AND deleted = 0")
    int softDelete(@Param("id") Long id);
}

