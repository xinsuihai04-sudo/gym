package com.example.gym.equipment.service;

import com.example.gym.equipment.domain.Equipment;

import java.util.List;

public interface EquipmentService {

    List<Equipment> listAll();

    Equipment getById(Long id);

    Long create(Equipment equipment);

    void update(Equipment equipment);

    void delete(Long id);
}

