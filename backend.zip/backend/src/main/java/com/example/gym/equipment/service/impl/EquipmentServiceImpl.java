package com.example.gym.equipment.service.impl;

import com.example.gym.common.BizException;
import com.example.gym.equipment.domain.Equipment;
import com.example.gym.equipment.mapper.EquipmentMapper;
import com.example.gym.equipment.service.EquipmentService;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;

@Service
public class EquipmentServiceImpl implements EquipmentService {

    private final EquipmentMapper equipmentMapper;

    public EquipmentServiceImpl(EquipmentMapper equipmentMapper) {
        this.equipmentMapper = equipmentMapper;
    }

    @Override
    public List<Equipment> listAll() {
        return equipmentMapper.findAll();
    }

    @Override
    public Equipment getById(Long id) {
        return equipmentMapper.findById(id);
    }

    @Override
    public Long create(Equipment equipment) {
        equipmentMapper.insert(equipment);
        return equipment.getId();
    }

    @Override
    public void update(Equipment equipment) {
        if (equipment == null || equipment.getId() == null) {
            throw new BizException(400, "BAD_REQUEST_BODY");
        }
        if (!StringUtils.hasText(equipment.getName())) {
            throw new BizException(400, "BAD_REQUEST_BODY");
        }
        if (equipment.getStatus() == null) {
            equipment.setStatus(1);
        }
        int updated = equipmentMapper.update(equipment);
        if (updated == 0) {
            throw new BizException(404, "EQUIPMENT_NOT_FOUND");
        }
    }

    @Override
    public void delete(Long id) {
        int updated = equipmentMapper.softDelete(id);
        if (updated == 0) {
            throw new BizException(404, "EQUIPMENT_NOT_FOUND");
        }
    }
}

