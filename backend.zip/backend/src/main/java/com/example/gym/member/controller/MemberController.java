package com.example.gym.member.controller;

import com.example.gym.common.ApiResponse;
import com.example.gym.common.BizException;
import com.example.gym.common.PagedResult;
import com.example.gym.member.domain.Member;
import com.example.gym.member.service.MemberService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/members")
public class MemberController {

    private final MemberService memberService;

    public MemberController(MemberService memberService) {
        this.memberService = memberService;
    }

    @GetMapping
    public ApiResponse<List<Member>> list() {
        try {
            return ApiResponse.success(memberService.listAll());
        } catch (Exception e) {
            e.printStackTrace();
            return ApiResponse.success(java.util.Collections.emptyList());
        }
    }

    /** 分页必须放在 /{id} 之前，否则 GET /api/members/page 会被匹配成 id=page 导致 500 */
    @GetMapping("/page")
    public ApiResponse<PagedResult<Member>> listByPage(
            @RequestParam(value = "pageNum", defaultValue = "1") int pageNum,
            @RequestParam(value = "pageSize", defaultValue = "10") int pageSize,
            @RequestParam(value = "keyword", required = false) String keyword) {
        try {
            PagedResult<Member> result = memberService.listByPage(pageNum, pageSize, keyword);
            return ApiResponse.success(result);
        } catch (Exception e) {
            e.printStackTrace();
            return ApiResponse.success(new PagedResult<>(java.util.Collections.emptyList(), 0L, pageNum, pageSize));
        }
    }

    @GetMapping("/{id}")
    public ApiResponse<Member> detail(@PathVariable("id") Long id) {
        Member member = memberService.getById(id);
        if (member == null) {
            throw new BizException(404, "MEMBER_NOT_FOUND");
        }
        return ApiResponse.success(member);
    }

    @PostMapping
    public ApiResponse<Long> create(@RequestBody Member member) {
        return ApiResponse.success(memberService.create(member));
    }

    @PutMapping("/{id}")
    public ApiResponse<Void> update(@PathVariable("id") Long id, @RequestBody Member member) {
        member.setId(id);
        memberService.update(member);
        return ApiResponse.success();
    }

    @DeleteMapping("/{id}")
    public ApiResponse<Void> delete(@PathVariable("id") Long id) {
        memberService.delete(id);
        return ApiResponse.success();
    }
}

