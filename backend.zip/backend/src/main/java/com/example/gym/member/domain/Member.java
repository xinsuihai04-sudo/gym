package com.example.gym.member.domain;

import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class Member {

    private Long id;
    private Long userId;
    private Integer gender;
    private LocalDate birthday;
    private Integer heightCm;
    private Double weightKg;
    private LocalDate joinDate;
    private Integer level;
    private String remark;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private Integer deleted;
}

