package com.example.gym.member.mapper;

import com.example.gym.member.domain.Member;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface MemberMapper {

    @Select("""
            SELECT id, user_id AS userId, gender, birthday, height_cm AS heightCm, weight_kg AS weightKg,
                   join_date AS joinDate, level, remark, created_at AS createdAt, updated_at AS updatedAt, deleted
            FROM gym_member
            WHERE deleted = 0
            ORDER BY id DESC
            """)
    List<Member> findAll();

    @Select("""
            SELECT id, user_id AS userId, gender, birthday, height_cm AS heightCm, weight_kg AS weightKg,
                   join_date AS joinDate, level, remark, created_at AS createdAt, updated_at AS updatedAt, deleted
            FROM gym_member
            WHERE id = #{id} AND deleted = 0
            """)
    Member findById(@Param("id") Long id);

    @Select("""
            SELECT id, user_id AS userId, gender, birthday, height_cm AS heightCm, weight_kg AS weightKg,
                   join_date AS joinDate, level, remark, created_at AS createdAt, updated_at AS updatedAt, deleted
            FROM gym_member
            WHERE user_id = #{userId} AND deleted = 0
            LIMIT 1
            """)
    Member findByUserId(@Param("userId") Long userId);

    @Insert("""
            INSERT INTO gym_member (user_id, gender, birthday, height_cm, weight_kg, join_date, level, remark)
            VALUES (#{userId}, #{gender}, #{birthday}, #{heightCm}, #{weightKg}, #{joinDate}, #{level}, #{remark})
            """)
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(Member member);

    @Update("""
            UPDATE gym_member
            SET gender = #{gender},
                birthday = #{birthday},
                height_cm = #{heightCm},
                weight_kg = #{weightKg},
                level = #{level},
                remark = #{remark}
            WHERE id = #{id} AND deleted = 0
            """)
    int update(Member member);

    @Select("""
            SELECT COUNT(*) FROM gym_member WHERE deleted = 0
            """)
    long countAll();

    @Select("""
            SELECT COUNT(*) FROM gym_member
            WHERE deleted = 0 AND remark LIKE CONCAT('%', #{keyword}, '%')
            """)
    long countByKeyword(@Param("keyword") String keyword);

    @Select("""
            SELECT id, user_id AS userId, gender, birthday, height_cm AS heightCm, weight_kg AS weightKg,
                   join_date AS joinDate, level, remark, created_at AS createdAt, updated_at AS updatedAt, deleted
            FROM gym_member
            WHERE deleted = 0
            ORDER BY id DESC
            LIMIT #{pageSize} OFFSET #{offset}
            """)
    List<Member> findByPage(@Param("offset") long offset, @Param("pageSize") int pageSize);

    @Select("""
            SELECT id, user_id AS userId, gender, birthday, height_cm AS heightCm, weight_kg AS weightKg,
                   join_date AS joinDate, level, remark, created_at AS createdAt, updated_at AS updatedAt, deleted
            FROM gym_member
            WHERE deleted = 0 AND remark LIKE CONCAT('%', #{keyword}, '%')
            ORDER BY id DESC
            LIMIT #{pageSize} OFFSET #{offset}
            """)
    List<Member> findByPageWithKeyword(@Param("offset") long offset, @Param("pageSize") int pageSize, @Param("keyword") String keyword);

    @Update("UPDATE gym_member SET deleted = 1 WHERE id = #{id} AND deleted = 0")
    int softDelete(@Param("id") Long id);
}

