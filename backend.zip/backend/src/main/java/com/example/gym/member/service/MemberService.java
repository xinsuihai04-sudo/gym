package com.example.gym.member.service;

import com.example.gym.common.PagedResult;
import com.example.gym.member.domain.Member;

import java.util.List;

public interface MemberService {

    List<Member> listAll();

    Member getById(Long id);

    Long create(Member member);

    void update(Member member);

    void delete(Long id);

    PagedResult<Member> listByPage(int pageNum, int pageSize, String keyword);
}

