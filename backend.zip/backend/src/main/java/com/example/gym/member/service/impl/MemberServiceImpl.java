package com.example.gym.member.service.impl;

import com.example.gym.common.PagedResult;
import com.example.gym.common.BizException;
import com.example.gym.member.domain.Member;
import com.example.gym.member.mapper.MemberMapper;
import com.example.gym.member.service.MemberService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class MemberServiceImpl implements MemberService {

    private final MemberMapper memberMapper;

    public MemberServiceImpl(MemberMapper memberMapper) {
        this.memberMapper = memberMapper;
    }

    @Override
    @Transactional(readOnly = true)
    public List<Member> listAll() {
        return memberMapper.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Member getById(Long id) {
        return memberMapper.findById(id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Long create(Member member) {
        if (member.getUserId() == null) {
            throw new BizException(400, "MEMBER_USER_ID_REQUIRED");
        }
        if (memberMapper.findByUserId(member.getUserId()) != null) {
            throw new BizException(400, "MEMBER_USER_ID_DUPLICATE");
        }
        memberMapper.insert(member);
        return member.getId();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void update(Member member) {
        int updated = memberMapper.update(member);
        if (updated == 0) {
            throw new BizException(404, "MEMBER_NOT_FOUND");
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void delete(Long id) {
        int updated = memberMapper.softDelete(id);
        if (updated == 0) {
            throw new BizException(404, "MEMBER_NOT_FOUND");
        }
    }

    @Override
    @Transactional(readOnly = true)
    public PagedResult<Member> listByPage(int pageNum, int pageSize, String keyword) {
        try {
            boolean hasKeyword = keyword != null && !keyword.trim().isEmpty();
            long total = hasKeyword ? memberMapper.countByKeyword(keyword.trim()) : memberMapper.countAll();
            long offset = (long) (pageNum - 1) * pageSize;
            List<Member> list = hasKeyword
                    ? memberMapper.findByPageWithKeyword(offset, pageSize, keyword.trim())
                    : memberMapper.findByPage(offset, pageSize);
            return new PagedResult<>(list, total, pageNum, pageSize);
        } catch (Exception e) {
            e.printStackTrace();
            return new PagedResult<>(java.util.Collections.emptyList(), 0L, pageNum, pageSize);
        }
    }
}

