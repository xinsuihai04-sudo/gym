package com.example.gym.system.mapper;

import com.example.gym.system.domain.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface UserMapper {

    @Select("""
            SELECT id, username, password, nickname, phone, email, avatar,
                   status, user_type AS userType,
                   last_login_at AS lastLoginAt, created_at AS createdAt, updated_at AS updatedAt, deleted
            FROM sys_user
            WHERE username = #{username} AND deleted = 0
            """)
    User findByUsername(@Param("username") String username);
}

