-- 初始化数据
-- 注意：所有密码都是 '123456' 的 BCrypt 加密值

-- 插入系统用户
-- admin 用户（管理员）
INSERT INTO gym_user (username, password, user_type, status) VALUES
('admin', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 1, 1);

-- 教练用户
INSERT INTO gym_user (username, password, user_type, status) VALUES
('coach1', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 2, 1),
('coach2', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 2, 1);

-- 会员用户
INSERT INTO gym_user (username, password, user_type, status) VALUES
('member1', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 3, 1),
('member2', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 3, 1),
('member3', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 3, 1);

-- 插入会员数据
INSERT INTO gym_member (user_id, gender, birthday, height_cm, weight_kg, join_date, level, remark) VALUES
(4, 1, '1990-05-15', 175, 70.5, '2024-01-10', 2, '活跃会员，喜欢力量训练'),
(5, 2, '1995-08-22', 162, 55.2, '2024-02-15', 1, '新会员，主要参加瑜伽课程'),
(6, 1, '1988-11-30', 180, 80.0, '2023-11-20', 3, '资深会员，每周训练5次');

-- 插入教练数据
INSERT INTO gym_coach (user_id, title, intro, years_exp, specialty, rating) VALUES
(2, '高级私人教练', '国家一级健身教练，擅长增肌减脂训练', 8, '力量训练、体能训练', 4.8),
(3, '瑜伽导师', '国际瑜伽协会认证导师，拥有10年教学经验', 10, '瑜伽、普拉提、拉伸', 4.9);

-- 插入课程数据
INSERT INTO gym_course (name, cover_url, description, max_participants, duration_min, difficulty, coach_id) VALUES
('力量训练入门', 'https://example.com/course1.jpg', '适合初学者的力量训练课程，学习基本动作技巧', 15, 60, 1, 1),
('高温瑜伽', 'https://example.com/course2.jpg', '在高温环境下进行的瑜伽练习，增强柔韧性和排毒', 12, 90, 2, 2),
('动感单车', 'https://example.com/course3.jpg', '高强度的有氧运动，配合音乐节奏燃烧脂肪', 20, 45, 3, 1),
('核心训练', 'https://example.com/course4.jpg', '专注于腹部和背部核心肌群的训练', 18, 60, 2, 2);

-- 插入器材数据
INSERT INTO gym_equipment (equipment_code, name, type, location, status, install_date) VALUES
('EQ001', '跑步机-01', '有氧器材', '有氧区A区', 1, '2023-05-10'),
('EQ002', '动感单车-01', '有氧器材', '有氧区B区', 1, '2023-05-12'),
('EQ003', '史密斯机', '力量器材', '力量区A区', 1, '2023-06-01'),
('EQ004', '卧推架', '力量器材', '力量区B区', 3, '2023-06-05'),
('EQ005', '椭圆机-01', '有氧器材', '有氧区C区', 2, '2023-07-20'),
('EQ006', '哑铃架', '力量器材', '力量区C区', 1, '2023-08-15');