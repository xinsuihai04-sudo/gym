-- 健身房管理系统数据库表结构
-- 使用 MySQL 8.0+

-- 系统用户表（用于登录）
CREATE TABLE IF NOT EXISTS gym_user (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE COMMENT '用户名',
    password VARCHAR(100) NOT NULL COMMENT '密码（BCrypt加密）',
    user_type TINYINT NOT NULL DEFAULT 1 COMMENT '用户类型：1-管理员，2-教练，3-会员',
    status TINYINT NOT NULL DEFAULT 1 COMMENT '状态：1-正常，0-禁用',
    deleted TINYINT NOT NULL DEFAULT 0 COMMENT '软删除标记：0-未删除，1-已删除',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_username (username),
    INDEX idx_status (status)
) COMMENT '系统用户表';

-- 会员表
CREATE TABLE IF NOT EXISTS gym_member (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT NOT NULL COMMENT '关联的用户ID',
    gender TINYINT COMMENT '性别：1-男，2-女',
    birthday DATE COMMENT '生日',
    height_cm INT COMMENT '身高（厘米）',
    weight_kg DECIMAL(5,2) COMMENT '体重（千克）',
    join_date DATE NOT NULL COMMENT '入会日期',
    level TINYINT DEFAULT 1 COMMENT '会员等级：1-普通，2-银卡，3-金卡，4-钻石',
    remark VARCHAR(500) COMMENT '备注',
    deleted TINYINT NOT NULL DEFAULT 0 COMMENT '软删除标记：0-未删除，1-已删除',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_join_date (join_date),
    INDEX idx_deleted (deleted)
) COMMENT '会员表';

-- 教练表
CREATE TABLE IF NOT EXISTS gym_coach (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT NOT NULL COMMENT '关联的用户ID',
    title VARCHAR(100) COMMENT '头衔',
    intro TEXT COMMENT '简介',
    years_exp INT COMMENT '从业年限',
    specialty VARCHAR(200) COMMENT '擅长领域',
    rating DECIMAL(3,1) DEFAULT 5.0 COMMENT '评分（1-5分）',
    deleted TINYINT NOT NULL DEFAULT 0 COMMENT '软删除标记：0-未删除，1-已删除',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_deleted (deleted)
) COMMENT '教练表';

-- 课程表
CREATE TABLE IF NOT EXISTS gym_course (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL COMMENT '课程名称',
    cover_url VARCHAR(500) COMMENT '封面图URL',
    description TEXT COMMENT '课程描述',
    max_participants INT NOT NULL DEFAULT 20 COMMENT '最大参与人数',
    duration_min INT NOT NULL DEFAULT 60 COMMENT '时长（分钟）',
    difficulty TINYINT NOT NULL DEFAULT 1 COMMENT '难度：1-初级，2-中级，3-高级',
    coach_id BIGINT COMMENT '负责教练ID',
    deleted TINYINT NOT NULL DEFAULT 0 COMMENT '软删除标记：0-未删除，1-已删除',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_coach_id (coach_id),
    INDEX idx_difficulty (difficulty),
    INDEX idx_deleted (deleted)
) COMMENT '课程表';

-- 器材表
CREATE TABLE IF NOT EXISTS gym_equipment (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    equipment_code VARCHAR(50) NOT NULL UNIQUE COMMENT '设备编码',
    name VARCHAR(100) NOT NULL COMMENT '设备名称',
    type VARCHAR(50) COMMENT '设备类型',
    location VARCHAR(200) COMMENT '安装位置',
    status TINYINT NOT NULL DEFAULT 1 COMMENT '状态：1-正常，2-故障，3-维护中，4-停用',
    install_date DATE COMMENT '安装日期',
    last_online_at DATETIME COMMENT '最后在线时间',
    deleted TINYINT NOT NULL DEFAULT 0 COMMENT '软删除标记：0-未删除，1-已删除',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_equipment_code (equipment_code),
    INDEX idx_status (status),
    INDEX idx_deleted (deleted)
) COMMENT '器材表';