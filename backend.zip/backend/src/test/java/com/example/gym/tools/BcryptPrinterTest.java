package com.example.gym.tools;

import org.junit.jupiter.api.Test;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class BcryptPrinterTest {

    @Test
    void print() {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        System.out.println("BCrypt(123456)=" + encoder.encode("123456"));
    }
}

