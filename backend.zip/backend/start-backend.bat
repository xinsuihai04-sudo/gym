@echo off
REM 健身房后端启动脚本
REM 自动检测可用端口并启动Spring Boot应用

setlocal enabledelayedexpansion

REM 起始端口
set START_PORT=18091
set MAX_ATTEMPTS=20

echo 正在查找可用端口...

for /l %%i in (0,1,%MAX_ATTEMPTS%) do (
    set /a PORT=START_PORT + %%i
    echo 尝试端口 !PORT!...

    REM 检查端口是否被占用
    netstat -ano | findstr ":!PORT! " > nul
    if errorlevel 1 (
        echo 端口 !PORT! 可用，启动后端...
        set SERVER_PORT=!PORT!

        REM 显示启动信息
        echo.
        echo ========================================
        echo 后端启动配置完成
        echo ========================================
        echo 后端端口: !PORT!
        echo 后端地址: http://localhost:!PORT!
        echo.
        echo 前端配置:
        echo 1. 设置环境变量 VITE_API_PORT=!PORT!
        echo 2. 或修改 frontend/vite.config.mts 中的代理地址
        echo.
        echo 启动前端的方法:
        echo 方法1: 在前端目录运行: set VITE_API_PORT=!PORT! && npm run dev
        echo 方法2: 直接运行 frontend/start-frontend.bat 并输入端口 !PORT!
        echo ========================================
        echo.

        REM 询问用户是否继续启动后端
        set /p CONFIRM=是否立即启动后端? (Y/N, 默认Y):
        if /i "%CONFIRM%"=="N" (
            echo 已取消启动。
            echo 请手动运行: mvn spring-boot:run -Dserver.port=!PORT!
            pause
            goto :end
        )

        echo 正在启动后端应用...
        echo 注意: 按Ctrl+C停止应用
        echo.

        REM 设置环境变量并启动
        set SERVER_PORT=!PORT!
        mvn spring-boot:run -Dserver.port=!PORT!

        REM 如果应用退出，提示用户
        echo.
        echo 后端已停止。
        pause
        goto :end
    ) else (
        echo 端口 !PORT! 被占用，尝试下一个...
    )
)

echo 错误: 在 %START_PORT% 到 %MAX_ATTEMPTS% 范围内未找到可用端口。
echo 请手动终止占用端口的进程或修改起始端口。
pause
exit /b 1

:end
endlocal