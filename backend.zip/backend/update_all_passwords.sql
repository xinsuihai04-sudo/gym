UPDATE gym_user 
SET password = '$2a$10$iKF7FuhIOTi.t7etlTz3Ie/sYgsRSlhOM8ysh6x3EWYr7winrY3ra'
WHERE username IN ('admin', 'coach1', 'coach2', 'member1', 'member2', 'member3');
