# 脚本说明

## release-ports.bat（释放端口）

当后端或前端提示“端口已被占用”时：

1. 双击运行 `release-ports.bat`
2. 脚本会结束占用 **18080**（后端）和 **5174**（前端）的进程
3. 若提示权限不足，请右键选择“以管理员身份运行”

完成后重新启动后端和前端即可。

## 端口配置说明

| 服务   | 默认端口 | 修改方式 |
|--------|----------|----------|
| 后端   | 18080    | 修改 `backend/src/main/resources/application.yml` 中的 `server.port`，或设置环境变量 `SERVER_PORT=端口号` |
| 前端   | 5174     | 修改 `frontend/vite.config.mts` 中的 `server.port`，或设置环境变量 `VITE_DEV_PORT=端口号`；前端代理的后端地址可通过 `VITE_API_TARGET` 修改 |

前端端口被占用时，Vite 会自动尝试使用下一个可用端口（如 5175、5176）。
