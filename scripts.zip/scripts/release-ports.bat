@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo 正在释放端口 18080（后端）和 5174（前端）...
echo.

for %%P in (18080 5174) do (
  for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":%%P" ^| findstr "LISTENING"') do (
    set "PID=%%a"
    echo 端口 %%P 被 PID !PID! 占用，正在结束...
    taskkill /F /PID !PID! 2>nul
    if !errorlevel! equ 0 (echo 已结束.) else (echo 需管理员权限时请右键“以管理员身份运行”.)
  )
)

echo.
echo 完成。可重新启动后端与前端。
pause
